package com.example.thewitchking.carshare;

import android.app.Application;

import com.firebase.client.Firebase;

public class Sharing extends Application {

    @Override
    public void onCreate() {
        super.onCreate();
        Firebase.setAndroidContext(this);
    }
}
